<div class="form-group">
	{!!Form::label('genre','Nombre: ')!!}
	{!!Form::text('genre',null, ['id'=>'genre','class'=>'form-control', 'placeholder' => 'Ingresa el nombre'])!!}
</div>