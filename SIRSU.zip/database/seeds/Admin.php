<?php

use Illuminate\Database\Seeder;

class Admin extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         DB::table('users')->insert([
            'name' => 'ADMINISTRADOR',
            'email' => 'franktovar3012@gmail.com',
            'password' => bcrypt('123456'),
        ]);
    }
}

/*
*   1- php artisan db:seed
*
*   2- php artisan db:seed --class=Admin
*/